# Chryzal Beaudelaire ZOSSOU 2022
# Performance Profiles for Machine Learning Python library
# Author: Chryzal Beaudelaire ZOSSOU <bchryzal@gmail.com>
#
# License: MIT

import os

# Create PPML Folder
PPML_DIR = './ppml'
try:
  os.mkdir(PPML_DIR)
except:
  print('')


__version__ = "0.1.0"