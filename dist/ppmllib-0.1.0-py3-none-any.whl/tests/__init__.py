# Chryzal Beaudelaire ZOSSOU 2022
# Performance Profiles for Machine Learning Python library
# Author: Chryzal Beaudelaire ZOSSOU <bchryzal@gmail.com>
#
# License: MIT
